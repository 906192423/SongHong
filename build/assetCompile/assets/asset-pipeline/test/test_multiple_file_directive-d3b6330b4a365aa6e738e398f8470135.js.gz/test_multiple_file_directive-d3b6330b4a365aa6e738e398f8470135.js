//# sourceMappingURL=asset-pipeline/test/test_multiple_file_directive.js.map
console.log("Initial Testing Stack for dependency load order");