//# sourceMappingURL=asset-pipeline/test/libs/subset/subset_a.js.map
console.log("Subset A");