//# sourceMappingURL=asset-pipeline/test/libs/file_c.js.map
console.log("This is File C");