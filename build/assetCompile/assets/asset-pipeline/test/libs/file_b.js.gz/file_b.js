//# sourceMappingURL=asset-pipeline/test/libs/file_b.js.map
console.log("This is File C");console.log("This is File B");